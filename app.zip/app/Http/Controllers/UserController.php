<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function login($phone, $password)
    {
        $user_data = DB::table('users')
            ->where('phone', "=", trim($phone))
            ->where('password', "=", trim($password))
            ->select("users.id", 'users.username', 'users.name', 'users.email')
            ->get();


        if (count($user_data) > 0) {

            $user = [];
            $user['name'] = $user_data[0]->name;
            $user['id'] = $user_data[0]->id;
            $user['username'] = $user_data[0]->username;
            $user['email'] = $user_data[0]->email;

            $response = [];
            $response['error'] = false;
            $response['message'] = 'success';
            $response['user'] = $user;

            return $response;

        } else {
            $user = [];
            $user['name'] = "";
            $user['id'] = 0;
            $user['username'] = "";
            $user['email'] = "";
            $response = [];
            $response['error'] = true;
            $response['message'] = 'failed';
            $response['user'] = $user;

            return $response;
        }

    }


    public function getUserUsingPhone($phone)
    {
        $data = DB::table("users")
            ->where("phone", "=", $phone)
            ->select("users.id")
            ->get();

        return $data[0]->id;
    }

    public function getUserUsingUsername($username)
    {
        $data = DB::table("users")
            ->where("username", "=", $username)
            ->select("users.id")
            ->get();

        return $data[0]->id;
    }

    public function getUserUsingEmail($email)
    {
        $data = DB::table("users")
            ->where("email", "=", $email)
            ->select("users.id")
            ->get();

        return $data[0]->id;
    }

    public function getRegisteredUsers($user, $phones)
    {

        $users_data = DB::table('users')
            ->whereIn('phone', explode(",", trim($phones)))
            ->select(
                'users.id',
                'users.name',
                'users.username',
                'users.phone',
//                DB::raw("(SELECT friends.id from friends WHERE (a=$user and b=users.id) or (a=users.id and b=$user)) as fid"),
//                DB::raw("(SELECT count(*) from friends WHERE (a=$user and b=users.id) or (a=users.id and b=$user)) as fcnt"),
//                DB::raw("(SELECT friends.friendship_type from friends WHERE (a=$user and b=users.id) or (a=users.id and b=$user)) as ffst"),
                DB::raw("(SELECT friends.friendship_type from friends WHERE (a=$user and b=users.id)) as ffst1"),
                DB::raw("(SELECT friends.friendship_type from friends WHERE (a=users.id and b=$user)) as ffst2")
            )
            ->get();

//        return $users_data;

        $types_data = DB::table("friendship_types")
            ->select("friendship_types.*")
            ->get();

        $users = [];
        foreach ($users_data as $user_data) {

            $user = [];
            $user['id'] = $user_data->id;
            $user['name'] = $user_data->name;
            $user['username'] = $user_data->username;
            $user['phone'] = $user_data->phone;

            $ffst = 0;
            if (is_null($user_data->ffst1) == true && is_null($user_data->ffst2) == true) {
                $ffst = 0;
            } else if ($user_data->ffst1 == 3 || $user_data->ffst2 == 3) {
                $ffst = 3;
            } else if ($user_data->ffst1 == 1 && is_null($user_data->ffst2) == true) {
                $ffst = 11;
            } else if (is_null($user_data->ffst1) == true && $user_data->ffst2 == 1) {
                $ffst = 12;
            } else if ($user_data->ffst1 == 2 && is_null($user_data->ffst2) == true) {
                $ffst = 21;
            } else if (is_null($user_data->ffst1) == true && $user_data->ffst2 == 2) {
                $ffst = 22;
            }

//            if (is_null($user_data->ffst) == true) {
//                $ffst = 0;
//            } else {
//                $ffst = $user_data->ffst;
//            }

            $type = [];
            switch ($ffst) {
                case 0 :
                    $type ['id'] = 0;
                    $type ['title'] = "none";
                    break;
                case 3 :
                    $type ['id'] = 3;
                    $type ['title'] = "accepted";
                    break;
                case 11 :
                    $type ['id'] = 11;
                    $type ['title'] = "i requested";
                    break;
                case 12:
                    $type ['id'] = 12;
                    $type ['title'] = "i got requested";
                    break;
                case 21 :
                    $type ['id'] = 21;
                    $type ['title'] = "i rejected";
                    break;
                case 22 :
                    $type ['id'] = 22;
                    $type ['title'] = "i got rejected";
                    break;
            }


//            $type = [];
//            if ($ffst == 0) {
//                $type ['id'] = 0;
//                $type ['title'] = "none";
//            } else {
//                $type ['id'] = $types_data[$ffst - 1]->id;
//                $type ['title'] = $types_data[$ffst - 1]->title;
//            }


            $user['friendship_type'] = $type;
            $users[] = $user;
        }

        $response = [];
        $response['error'] = false;
        $response['message'] = 'success';
        $response['users'] = $users;


        return $response;
    }

    public function register(Request $request)
    {
        $digits = 5;
        $verification_code = rand(pow(10, $digits - 1), pow(10, $digits) - 1);
        $data['name'] = $request->input('name');
        $data['email'] = $request->input('email');
        $data['username'] = $request->input('username');
        $data['phone'] = $request->input('phone');
        $data['password'] = $request->input('password');
        $data['verification_code'] = $verification_code;
        $data['activated'] = 0;

        $user = new User();
        $user->insert($data);
        $id = $user->id;


        $this->sendSMS($data['phone'], $verification_code);

        $response = [];
        $response['error'] = false;
        $response['message'] = $data['name'] . ' added';
        return $response;
    }

    public function sendSMS($phone, $verification_code)
    {

//        $BASE_HTTP_URL = "http://www.sibsms.com/APISend.aspx?";

        $USERNAME = "09112450877";
        $PASSWORD = "Nemesis1358";
        $senderNumber = "50002030005969";
        $message = "your verification code is $verification_code";

        $url = "http://www.sibsms.com/APISend.aspx?";
        $options = array(
            "Username" => $USERNAME,
            "Password" => $PASSWORD,
            "From" => $senderNumber,
            "To" => $phone,
            "Text" => $message
        );

        $url .= http_build_query($options, '', '&');

        $myData = file_get_contents($url) or die(print_r(error_get_last()));

    }


    public function verify($phone, $verification_code)
    {
        $user_data = DB::table('users')
            ->where("users.phone", "=", $phone)
            ->where("users.activated", "=", 0)
            ->select("users.id", "users.verification_code")
            ->get();

        if (count($user_data) == 0) {
            $response = [];
            $response['error'] = true;
            $response['message'] = "phone number not registered";
            return $response;
        }

        $id = $user_data[0]->id;
        if ($user_data[0]->verification_code == $verification_code) {

            DB::table('users')->where('id', "=", $id)->update(array(
                'activated' => 1));
            $response = [];
            $response['error'] = false;
            $response['message'] = "account activated";
            return $response;

        } else {
            $response = [];
            $response['error'] = false;
            $response['message'] = "verification code is wrong";
            return $response;
        }

    }


    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
