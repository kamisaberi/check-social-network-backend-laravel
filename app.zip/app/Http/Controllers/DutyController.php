<?php

namespace App\Http\Controllers;

use App\Duty;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DutyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function getDuties($creator)
    {

        $duties_data = DB::table('duties')
            ->where('creator', "=", $creator)
            ->join('users', "users.id", "=", 'duties.creator')
            ->select('duties.id as did', 'duties.title', 'duties.parent', 'duties.creator', 'users.id as uid', 'users.name', 'users.email', 'users.username', 'users.phone')
            ->get();

        $duties = [];

        foreach ($duties_data as $duty_data) {
            $duty = [];

            $duty['id'] = $duty_data->did;
            $duty['title'] = $duty_data->title;
            $duty['parent'] = $duty_data->parent;

            $user = [];
            $user['id'] = $duty_data->uid;
            $user['name'] = $duty_data->name;
            $user['email'] = $duty_data->email;
            $user['username'] = $duty_data->username;
            $user['phone'] = $duty_data->phone;

            $duty['creator'] = $user;

            $logs_data = DB::table("logs")
                ->join('users', "logs.user", "=", "users.id")
                ->where('logs.duty', "=", $duty_data->did)
                ->select('logs.id as lid', 'logs.log', 'logs.date', 'users.id as uid', 'users.username', 'users.phone', 'users.email', 'users.name')
                ->get();

            $logs = [];
            foreach ($logs_data as $log_data) {

                $log = [];
                $log['id'] = $log_data->lid;
                $log['log'] = $log_data->log;
                $log['date'] = $log_data->date;

                $user = [];
                $user['id'] = $log_data->uid;
                $user['name'] = $log_data->name;
                $user['username'] = $log_data->username;
                $user['phone'] = $log_data->phone;
                $user['email'] = $log_data->email;

                $log['user'] = $user;

                $logs[] = $log;
            }
            $duty['logs'] = $logs;
            $duties[] = $duty;
        }

        $response = [];
        $response['error'] = false;
        $response['message'] = "success";
        $response['duties'] = $duties;

        return $response;
    }


    public function getDutiesAndGroups($creator)
    {

        $groups = [];

        $duties_data = DB::table('duties')
            ->where('creator', "=", $creator)
            ->join('users', "users.id", "=", 'duties.creator')
            ->join('priorities', "priorities.id", "=", 'duties.priority')
            ->select('duties.id as did', 'duties.title', 'duties.description', 'duties.parent', 'duties.creator', 'duties.start_date', 'duties.duration', 'duties.group', 'users.id as uid', 'users.name', 'users.email', 'users.username', 'users.phone', 'priorities.id as prid', 'priorities.title as prtt')
            ->where("duties.group", "=", 0)
            ->get();

        $no_grouped_duties = [];

        foreach ($duties_data as $duty_data) {
            $duty = [];

            $duty['id'] = $duty_data->did;
            $duty['title'] = $duty_data->title;
            $duty['description'] = $duty_data->description;
            $duty['parent'] = $duty_data->parent;
            $duty['start_date'] = $duty_data->start_date;
            $duty['duration'] = $duty_data->duration;
            $duty['group'] = $duty_data->group;

            $priority = [];
            $priority['id'] = $duty_data->prid;
            $priority['title'] = $duty_data->prtt;
            $duty['priority'] = $priority;

            $user = [];
            $user['id'] = $duty_data->uid;
            $user['name'] = $duty_data->name;
            $user['email'] = $duty_data->email;
            $user['username'] = $duty_data->username;
            $user['phone'] = $duty_data->phone;

            $duty['creator'] = $user;

            $logs_data = DB::table("logs")
                ->join('users', "logs.user", "=", "users.id")
                ->where('logs.duty', "=", $duty_data->did)
                ->select('logs.id as lid', 'logs.log', 'logs.date', 'users.id as uid', 'users.username', 'users.phone', 'users.email', 'users.name')
                ->get();

            $logs = [];
            foreach ($logs_data as $log_data) {

                $log = [];
                $log['id'] = $log_data->lid;
                $log['log'] = $log_data->log;
                $log['date'] = $log_data->date;

                $user = [];
                $user['id'] = $log_data->uid;
                $user['name'] = $log_data->name;
                $user['username'] = $log_data->username;
                $user['phone'] = $log_data->phone;
                $user['email'] = $log_data->email;

                $log['user'] = $user;

                $logs[] = $log;
            }
            $duty['logs'] = $logs;
            $no_grouped_duties[] = $duty;
        }


        $duties_data = DB::table('duties')
            ->join('user_duty', "user_duty.duty", "=", 'duties.id')
            ->join('users', "users.id", "=", 'duties.creator')
            ->join('priorities', "priorities.id", "=", 'duties.priority')
            ->select('duties.id as did', 'duties.title', 'duties.description', 'duties.parent', 'duties.creator', 'duties.start_date', 'duties.duration', 'duties.group', 'users.id as uid', 'users.name', 'users.email', 'users.username', 'users.phone', 'priorities.id as prid', 'priorities.title as prtt')
            ->where("duties.group", "=", 0)
            ->where('user_duty.user', "=", $creator)
            ->get();

        foreach ($duties_data as $duty_data) {
            $duty = [];

            $duty['id'] = $duty_data->did;
            $duty['title'] = $duty_data->title;
            $duty['description'] = $duty_data->description;
            $duty['parent'] = $duty_data->parent;
            $duty['start_date'] = $duty_data->start_date;
            $duty['duration'] = $duty_data->duration;
            $duty['group'] = $duty_data->group;

            $priority = [];
            $priority['id'] = $duty_data->prid;
            $priority['title'] = $duty_data->prtt;
            $duty['priority'] = $priority;

            $user = [];
            $user['id'] = $duty_data->uid;
            $user['name'] = $duty_data->name;
            $user['email'] = $duty_data->email;
            $user['username'] = $duty_data->username;
            $user['phone'] = $duty_data->phone;

            $duty['creator'] = $user;

            $logs_data = DB::table("logs")
                ->join('users', "logs.user", "=", "users.id")
                ->where('logs.duty', "=", $duty_data->did)
                ->select('logs.id as lid', 'logs.log', 'logs.date', 'users.id as uid', 'users.username', 'users.phone', 'users.email', 'users.name')
                ->get();

            $logs = [];
            foreach ($logs_data as $log_data) {

                $log = [];
                $log['id'] = $log_data->lid;
                $log['log'] = $log_data->log;
                $log['date'] = $log_data->date;

                $user = [];
                $user['id'] = $log_data->uid;
                $user['name'] = $log_data->name;
                $user['username'] = $log_data->username;
                $user['phone'] = $log_data->phone;
                $user['email'] = $log_data->email;

                $log['user'] = $user;

                $logs[] = $log;
            }
            $duty['logs'] = $logs;
            $no_grouped_duties[] = $duty;
        }


        $group = [];
        $group ['id'] = 0;
        $group ['title'] = "no_group";
        $group["duties"] = $no_grouped_duties;
        $groups[] = $group;







//        $grouped_groups = [];


        $duties_data = DB::table('duties')
            ->where('duties.creator', "=", $creator)
            ->join('users', "users.id", "=", 'duties.creator')
            ->join('groups', "groups.id", "=", 'duties.group')
            ->join('priorities', "priorities.id", "=", 'duties.priority')
            ->select('duties.id as did', 'duties.title', 'duties.description', 'duties.parent', 'duties.creator', 'duties.start_date', 'duties.duration', 'duties.group', 'users.id as uid', 'users.name', 'users.email', 'users.username', 'users.phone', 'groups.id as gid', 'groups.title as gtl', 'priorities.id as prid', 'priorities.title as prtt')
            ->orderBy("groups.id", "ASC")
            ->get();

        $rgid = 0;
        $index = 0;
        $ids = [];
        $cur = 0;
        //$group = [];
        foreach ($duties_data as $duty_data) {

            if ($rgid != $duty_data->gid) {
                $rgid = $duty_data->gid;
                if (in_array($rgid, $ids) == false) {
                    $index++;
                    $cur = $index;
                    $groups[$cur]['id'] = $duty_data->gid;
                    $groups[$cur]['title'] = $duty_data->gtl;
                } else {
                    $cur = array_search($rgid, $ids);
                }
            }

            $duty = [];
            $duty['id'] = $duty_data->did;
            $duty['title'] = $duty_data->title;
            $duty['description'] = $duty_data->description;
            $duty['parent'] = $duty_data->parent;
            $duty['start_date'] = $duty_data->start_date;
            $duty['duration'] = $duty_data->duration;
            $duty['group'] = $duty_data->group;

            $priority = [];
            $priority['id'] = $duty_data->prid;
            $priority['title'] = $duty_data->prtt;
            $duty['priority'] = $priority;


            $user = [];
            $user['id'] = $duty_data->uid;
            $user['name'] = $duty_data->name;
            $user['email'] = $duty_data->email;
            $user['username'] = $duty_data->username;
            $user['phone'] = $duty_data->phone;

            $duty['creator'] = $user;

            $logs_data = DB::table("logs")
                ->join('users', "logs.user", "=", "users.id")
                ->where('logs.duty', "=", $duty_data->did)
                ->select('logs.id as lid', 'logs.log', 'logs.date', 'users.id as uid', 'users.username', 'users.phone', 'users.email', 'users.name')
                ->get();

            $logs = [];
            foreach ($logs_data as $log_data) {

                $log = [];
                $log['id'] = $log_data->lid;
                $log['log'] = $log_data->log;
                $log['date'] = $log_data->date;

                $user = [];
                $user['id'] = $log_data->uid;
                $user['name'] = $log_data->name;
                $user['username'] = $log_data->username;
                $user['phone'] = $log_data->phone;
                $user['email'] = $log_data->email;

                $log['user'] = $user;

                $logs[] = $log;
            }
            $duty['logs'] = $logs;
            $groups[$cur]['duties'][] = $duty;

        }


        $duties_data = DB::table('duties')
            ->join('user_duty', 'user_duty.duty', "=", 'duties.id')
            ->join('users', "users.id", "=", 'duties.creator')
            ->join('groups', "groups.id", "=", 'duties.group')
            ->join('priorities', "priorities.id", "=", 'duties.priority')
            ->select('duties.id as did', 'duties.title', 'duties.description', 'duties.parent', 'duties.creator', 'duties.start_date', 'duties.duration', 'duties.group', 'users.id as uid', 'users.name', 'users.email', 'users.username', 'users.phone', 'groups.id as gid', 'groups.title as gtl', 'priorities.id as prid', 'priorities.title as prtt')
            ->where('user_duty.user', "=", $creator)
            ->orderBy("groups.id", "ASC")
            ->get();


        $rgid = 0;
//        $index = 0;
        //$group = [];
        foreach ($duties_data as $duty_data) {

            if ($rgid != $duty_data->gid) {
                $rgid = $duty_data->gid;
                if (in_array($rgid, $ids) == false) {
                    $index++;
                    $cur = $index;
                    $groups[$cur]['id'] = $duty_data->gid;
                    $groups[$cur]['title'] = $duty_data->gtl;
                } else {
                    $cur = array_search($rgid, $ids);
                }
            }

            $duty = [];
            $duty['id'] = $duty_data->did;
            $duty['title'] = $duty_data->title;
            $duty['description'] = $duty_data->description;
            $duty['parent'] = $duty_data->parent;
            $duty['start_date'] = $duty_data->start_date;
            $duty['duration'] = $duty_data->duration;
            $duty['group'] = $duty_data->group;

            $priority = [];
            $priority['id'] = $duty_data->prid;
            $priority['title'] = $duty_data->prtt;
            $duty['priority'] = $priority;


            $user = [];
            $user['id'] = $duty_data->uid;
            $user['name'] = $duty_data->name;
            $user['email'] = $duty_data->email;
            $user['username'] = $duty_data->username;
            $user['phone'] = $duty_data->phone;

            $duty['creator'] = $user;

            $logs_data = DB::table("logs")
                ->join('users', "logs.user", "=", "users.id")
                ->where('logs.duty', "=", $duty_data->did)
                ->select('logs.id as lid', 'logs.log', 'logs.date', 'users.id as uid', 'users.username', 'users.phone', 'users.email', 'users.name')
                ->get();

            $logs = [];
            foreach ($logs_data as $log_data) {

                $log = [];
                $log['id'] = $log_data->lid;
                $log['log'] = $log_data->log;
                $log['date'] = $log_data->date;

                $user = [];
                $user['id'] = $log_data->uid;
                $user['name'] = $log_data->name;
                $user['username'] = $log_data->username;
                $user['phone'] = $log_data->phone;
                $user['email'] = $log_data->email;

                $log['user'] = $user;

                $logs[] = $log;
            }
            $duty['logs'] = $logs;
            $groups[$cur]['duties'][] = $duty;

        }


        $response = [];
        $response['error'] = false;
        $response['message'] = "success";
        $response['groups'] = $groups;

        return $response;
    }


    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $data['title'] = $request->input('title');
        $data['description'] = $request->input('description');
        $data['parent'] = $request->input('parent');
        $data['group'] = $request->input('group');
        $data['priority'] = $request->input('priority');
        $data['start_date'] = $request->input('start_date');
        $data['duration'] = $request->input('duration');
        $data['creator'] = $request->input('creator');


        $duty = new Duty();
        $duty->title = $data['title'];
        $duty->description = $data['description'];
        $duty->parent = $data['parent'];
        $duty->group = $data['group'];
        $duty->priority = $data['priority'];
        $duty->start_date = $data['start_date'];
        $duty->duration = $data['duration'];
        $duty->creator = $data['creator'];
        $duty->save();
        $id = $duty->id;


        $usrs = $request->input('users');
        $users = explode(',', $usrs);

        foreach ($users as $user) {
            DB::table("user_duty")
                ->insert(
                    array("duty" => $id, "user" => $user)
                );
        }


        $response = [];
        $response['error'] = false;
        $response['message'] = "$id";
        return $response;
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
