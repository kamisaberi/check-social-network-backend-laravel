<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


Route::get('/login/{phone}/{password}', "UserController@login")->name('users.login');

Route::get('/verify/{phone}/{verification_code}', "UserController@verify")->name('users.verify');


Route::post('/register', "UserController@register")->name('users.register');


Route::get('/duties/get/{creator}' , "DutyController@getDuties")->name('duties.get.duties');
Route::get('/groups/get/{creator}' , "DutyController@getDutiesAndGroups")->name('groups.get.groups');
Route::get('/users/registered/{user}/{phones}' , "UserController@getRegisteredUsers")->name('users.get.registered');

Route::get('/friends/get/{id}' , "FriendController@getFiendListForUser")->name('friends.get');

Route::get('/friends/get/username/{username}' , "FriendController@getFiendListForUserUsingUsername")->name('friends.get.username');


Route::post('/duties', "DutyController@store")->name('duties.store');
Route::post('/groups', "GroupController@store")->name('groups.store');

Route::post('/friends/change', "FriendController@changeFriendshipSituation")->name('friends.change');

Route::post('/friends/add', "FriendController@addFriendship")->name('friends.add');

Route::post('/friends/remove', "FriendController@removeFriendship")->name('friends.remove');

Route::post('logs', "LogController@store")->name('logs.store');
